# AWS Glue Data Quality Checks - PySpark Version

This folder contains the PySpark version of the data quality check script, designed to run on AWS Glue 5.0.

## 📁 Files Overview

### Core Files
- **`data_quality_glue.py`** - Main data quality engine class with PySpark logic
- **`glue_job_script.py`** - AWS Glue job entry point script
- **`glue_config.py`** - Configuration file for Redshift and Glue settings

### Deployment & Testing
- **`deploy_glue_job.py`** - Script to deploy the job to AWS Glue
- **`test_glue_local.py`** - Local testing script to validate logic before deployment
- **`requirements.txt`** - Dependencies (most are pre-installed in Glue 5.0)

## 🚀 Quick Start

### 1. Configure Settings
Edit `glue_config.py` with your environment details:

```python
REDSHIFT_CONFIG = {
    'host': 'your-redshift-cluster.region.redshift.amazonaws.com',
    'port': 5439,
    'database': 'your_database',
    'user': 'your_username',
    'password': 'your_password',
    'schema': 'dataquality'
}
```

### 2. Test Locally (Optional)
```bash
cd aws_glue_pyspark
python test_glue_local.py
```

### 3. Deploy to AWS Glue
```bash
# Update deployment script with your AWS details
python deploy_glue_job.py
```

### 4. Run the Job
```bash
# Using AWS CLI
aws glue start-job-run --job-name data-quality-checks-pyspark

# With custom process ID
aws glue start-job-run --job-name data-quality-checks-pyspark --arguments='--process_id=11'
```

## 🔧 Configuration

### AWS Glue Job Parameters
- `--process_id`: Process ID to run checks for (default: 11)
- `--log_level`: Logging level (default: INFO)
- `--temp_dir`: S3 temporary directory

### Spark Configuration
The job uses optimized Spark settings for Glue 5.0:
- Adaptive Query Execution enabled
- Dynamic partition coalescing
- Skew join optimization
- Kryo serialization

## 📊 Supported Check Types

### OOTB (Out of the Box) Checks
1. **OOTB_DUPCHECK** - Duplicate value detection
2. **OOTB_NOTNULL** - Null value detection
3. **OOTB_MAXVAL** - Maximum value threshold checks
4. **OOTB_NOTIN** - Value not in allowed list
5. **OOTB_FKEY_NOTFOUND** - Foreign key validation

### Custom Checks
- **COMPARE** - Source vs target comparison
- **Custom SQL** - Any custom SQL query

## 🗄️ Database Schema

The script expects these tables in your Redshift database:

### data_compare_check
```sql
CREATE TABLE dataquality.data_compare_check (
    process_id INTEGER,
    check_id INTEGER,
    active BOOLEAN,
    check_type VARCHAR(50),
    chunking_rule VARCHAR(100),
    key_cols VARCHAR(200),
    src_qry TEXT,
    tgt_qry TEXT
);
```

### data_compare_log
```sql
CREATE TABLE dataquality.data_compare_log (
    process_id INTEGER,
    run_id INTEGER,
    check_id INTEGER,
    run_status VARCHAR(50),
    numdiff INTEGER,
    run_duration DECIMAL(10,6),
    run_date TIMESTAMP,
    err_reason TEXT
);
```

### data_compare_diff
```sql
CREATE TABLE dataquality.data_compare_diff (
    process_id INTEGER,
    run_id INTEGER,
    check_id INTEGER,
    colname VARCHAR(100),
    pkeyval VARCHAR(500),
    srcval VARCHAR(500),
    tgtval VARCHAR(500)
);
```

## 🔍 Enhanced Features

### Detailed Duplicate Storage
Unlike the original script that only stored summary counts, this version stores detailed duplicate information:

```sql
-- Summary in data_compare_log
Status: FAILED-OOTB_DUPCHECK, Differences: 1

-- Details in data_compare_diff
Column: duplicate_check, Key: Gwendolyn, Source: 3, Target: DUPLICATE
```

### Error Handling
- Comprehensive error logging
- Graceful failure handling
- CloudWatch integration
- S3 metrics output

### Performance Optimizations
- Spark SQL for efficient processing
- Adaptive query execution
- Optimized JDBC connections
- Parallel processing support

## 📋 Prerequisites

### AWS Resources
1. **AWS Glue 5.0** environment
2. **Amazon Redshift** cluster with data quality tables
3. **S3 bucket** for scripts and temporary files
4. **IAM role** with appropriate permissions

### IAM Permissions
The Glue job role needs:
- Glue service permissions
- S3 read/write access
- Redshift connect permissions
- CloudWatch logs access

Example policy is provided in `deploy_glue_job.py`.

### Redshift JDBC Driver
Download the Redshift JDBC driver and upload to S3:
```bash
# Download from AWS
wget https://s3.amazonaws.com/redshift-downloads/drivers/jdbc/2.1.0.12/redshift-jdbc42-2.1.0.12.jar

# Upload to your S3 bucket
aws s3 cp redshift-jdbc42-2.1.0.12.jar s3://your-bucket/jars/
```

## 🧪 Testing

### Local Testing
The `test_glue_local.py` script creates mock data and tests the logic locally:

```bash
python test_glue_local.py
```

Expected output:
```
✅ Found 2 check configurations
✅ Found 1 duplicate groups
✅ Found 1 null values
🎉 All tests passed!
```

### Glue Testing
After deployment, test with a small dataset:

```bash
aws glue start-job-run --job-name data-quality-checks-pyspark --arguments='--process_id=99'
```

## 📈 Monitoring

### CloudWatch Logs
- Job execution logs: `/aws-glue/jobs/logs-v2/`
- Error logs: `/aws-glue/jobs/error/`
- Output logs: `/aws-glue/jobs/output/`

### S3 Metrics
Job metrics are written to S3:
- Success metrics: `s3://bucket/output/job_metrics/`
- Error metrics: `s3://bucket/output/job_errors/`

### Redshift Monitoring
Query the results tables:

```sql
-- Check execution summary
SELECT run_status, COUNT(*) as check_count, SUM(numdiff) as total_issues
FROM dataquality.data_compare_log 
WHERE run_id = (SELECT MAX(run_id) FROM dataquality.data_compare_log)
GROUP BY run_status;

-- Check detailed results
SELECT check_id, colname, pkeyval, srcval, tgtval
FROM dataquality.data_compare_diff 
WHERE run_id = (SELECT MAX(run_id) FROM dataquality.data_compare_log)
ORDER BY check_id;
```

## 🔄 Migration from Original Script

### Key Differences
1. **PySpark DataFrames** instead of pandas
2. **JDBC connections** instead of redshift-connector
3. **Distributed processing** instead of single-node
4. **AWS Glue integration** for job management
5. **Enhanced error handling** and monitoring

### Migration Steps
1. Set up AWS Glue environment
2. Create S3 buckets for scripts and temp files
3. Configure IAM roles and permissions
4. Deploy the Glue job
5. Test with existing check configurations
6. Monitor and validate results

## 🆘 Troubleshooting

### Common Issues

**JDBC Connection Errors**
- Verify Redshift security groups allow Glue access
- Check IAM role permissions
- Validate JDBC URL format

**Script Import Errors**
- Ensure all scripts are uploaded to S3
- Check S3 bucket permissions
- Verify script paths in job configuration

**Performance Issues**
- Increase worker count for large datasets
- Use appropriate worker types (G.1X, G.2X)
- Optimize Spark configurations

**Memory Errors**
- Increase worker memory (use G.2X or larger)
- Reduce batch sizes
- Enable dynamic allocation

### Debug Mode
Enable debug logging:
```bash
aws glue start-job-run --job-name data-quality-checks-pyspark --arguments='--log_level=DEBUG'
```

## 📞 Support

For issues or questions:
1. Check CloudWatch logs for detailed error messages
2. Review S3 error metrics
3. Validate Redshift connectivity
4. Test with local script first

## 🔄 Version History

- **v1.0** - Initial PySpark conversion from original script
- Enhanced duplicate detail storage
- AWS Glue 5.0 compatibility
- Comprehensive error handling and monitoring