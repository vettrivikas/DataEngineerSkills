"""
AWS Glue Configuration for Data Quality Checks
Compatible with AWS Glue 5.0 (Spark 3.4, Python 3.10)
"""

# Redshift Connection Configuration
REDSHIFT_CONFIG = {
    'host': 'your-redshift-cluster.region.redshift.amazonaws.com',
    'port': 5439,
    'database': 'your_database',
    'user': 'your_username',
    'password': 'your_password',
    'schema': 'dataquality'
}

# AWS Glue Job Parameters (can be overridden by job parameters)
GLUE_JOB_CONFIG = {
    'job_name': 'data-quality-checks',
    'temp_dir': 's3://your-bucket/temp/',
    'output_dir': 's3://your-bucket/output/',
    'log_level': 'INFO'
}

# Data Quality Configuration
DATA_QUALITY_CONFIG = {
    'process_id': 11,  # Default process ID, can be overridden
    'target_schema': 'dataquality',
    'metadata_tables': {
        'check_config': 'data_compare_check',
        'log_table': 'data_compare_log', 
        'diff_table': 'data_compare_diff'
    }
}

# Spark Configuration for Glue
SPARK_CONFIG = {
    'spark.sql.adaptive.enabled': 'true',
    'spark.sql.adaptive.coalescePartitions.enabled': 'true',
    'spark.sql.adaptive.skewJoin.enabled': 'true',
    'spark.serializer': 'org.apache.spark.serializer.KryoSerializer'
}