"""
Logic validation script for Glue data quality job
This script validates the SQL query generation logic without requiring PySpark
"""

def validate_ootb_query_logic():
    """Validate OOTB query generation logic"""
    
    print("🧪 Validating OOTB Query Generation Logic")
    
    # Test cases for different OOTB check types
    test_cases = [
        {
            'check_type': 'OOTB_DUPCHECK',
            'key_cols': 'first_name',
            'tgt_qry': 'dataquality.employee',
            'expected_count': 'SELECT COUNT(*) as count FROM (SELECT first_name, COUNT(*) FROM dataquality.employee GROUP BY first_name HAVING COUNT(*) > 1) t',
            'expected_detail': 'SELECT first_name, COUNT(*) as dup_count FROM dataquality.employee GROUP BY first_name HAVING COUNT(*) > 1'
        },
        {
            'check_type': 'OOTB_NOTNULL',
            'key_cols': None,
            'tgt_qry': 'dataquality.employee.job_title',
            'expected_count': 'SELECT COUNT(*) as count FROM dataquality.employee WHERE job_title IS NULL',
            'expected_detail': "SELECT 'job_title' as column_name, 'NULL' as failing_value FROM dataquality.employee WHERE job_title IS NULL LIMIT 1000"
        },
        {
            'check_type': 'OOTB_MAXVAL',
            'key_cols': 'age',
            'tgt_qry': 'dataquality.employee.age 65',
            'expected_count': 'SELECT COUNT(*) as count FROM dataquality.employee WHERE age > 65',
            'expected_detail': 'SELECT age as failing_value FROM dataquality.employee WHERE age > 65 LIMIT 1000'
        },
        {
            'check_type': 'OOTB_NOTIN',
            'key_cols': 'status',
            'tgt_qry': "dataquality.employee.status ('ACTIVE', 'INACTIVE')",
            'expected_count': "SELECT COUNT(*) as count FROM dataquality.employee WHERE status NOT IN (('ACTIVE', 'INACTIVE'))",
            'expected_detail': "SELECT status as failing_value FROM dataquality.employee WHERE status NOT IN (('ACTIVE', 'INACTIVE')) LIMIT 1000"
        }
    ]
    
    def build_ootb_query_logic(check_type, key_cols, tgt_qry):
        """Replicate the query building logic from the main script"""
        
        if check_type == 'OOTB_DUPCHECK':
            count_query = f"SELECT COUNT(*) as count FROM (SELECT {key_cols}, COUNT(*) FROM {tgt_qry} GROUP BY {key_cols} HAVING COUNT(*) > 1) t"
            detail_query = f"SELECT {key_cols}, COUNT(*) as dup_count FROM {tgt_qry} GROUP BY {key_cols} HAVING COUNT(*) > 1"
            
        elif check_type == 'OOTB_NOTNULL':
            parts = tgt_qry.split('.')
            if len(parts) >= 3:
                table_name = ".".join(parts[:-1])
                column_name = parts[-1]
            else:
                table_name = parts[0] if len(parts) == 2 else tgt_qry
                column_name = parts[1] if len(parts) == 2 else key_cols
            
            count_query = f"SELECT COUNT(*) as count FROM {table_name} WHERE {column_name} IS NULL"
            detail_query = f"SELECT '{column_name}' as column_name, 'NULL' as failing_value FROM {table_name} WHERE {column_name} IS NULL LIMIT 1000"
            
        elif check_type == 'OOTB_MAXVAL':
            space_idx = tgt_qry.find(' ')
            table_col = tgt_qry[:space_idx]
            threshold = tgt_qry[space_idx:].strip()
            
            parts = table_col.split('.')
            if len(parts) >= 2:
                table_name = ".".join(parts[:-1])
                column_name = parts[-1]
            else:
                table_name = parts[0]
                column_name = key_cols
            
            count_query = f"SELECT COUNT(*) as count FROM {table_name} WHERE {column_name} > {threshold}"
            detail_query = f"SELECT {column_name} as failing_value FROM {table_name} WHERE {column_name} > {threshold} LIMIT 1000"
            
        elif check_type == 'OOTB_NOTIN':
            space_idx = tgt_qry.find(' ')
            table_col = tgt_qry[:space_idx]
            allowed_values = tgt_qry[space_idx:].strip()
            
            parts = table_col.split('.')
            if len(parts) >= 2:
                table_name = ".".join(parts[:-1])
                column_name = parts[-1]
            else:
                table_name = parts[0]
                column_name = key_cols
            
            count_query = f"SELECT COUNT(*) as count FROM {table_name} WHERE {column_name} NOT IN ({allowed_values})"
            detail_query = f"SELECT {column_name} as failing_value FROM {table_name} WHERE {column_name} NOT IN ({allowed_values}) LIMIT 1000"
            
        else:
            raise ValueError(f"Unsupported OOTB check type: {check_type}")
        
        return count_query, detail_query
    
    # Run test cases
    all_passed = True
    
    for i, test_case in enumerate(test_cases, 1):
        print(f"\n📋 Test Case {i}: {test_case['check_type']}")
        
        try:
            count_query, detail_query = build_ootb_query_logic(
                test_case['check_type'],
                test_case['key_cols'],
                test_case['tgt_qry']
            )
            
            # Validate count query
            if count_query.strip() == test_case['expected_count'].strip():
                print(f"   ✅ Count query: PASS")
            else:
                print(f"   ❌ Count query: FAIL")
                print(f"      Expected: {test_case['expected_count']}")
                print(f"      Got:      {count_query}")
                all_passed = False
            
            # Validate detail query
            if detail_query.strip() == test_case['expected_detail'].strip():
                print(f"   ✅ Detail query: PASS")
            else:
                print(f"   ❌ Detail query: FAIL")
                print(f"      Expected: {test_case['expected_detail']}")
                print(f"      Got:      {detail_query}")
                all_passed = False
                
        except Exception as e:
            print(f"   ❌ Exception: {str(e)}")
            all_passed = False
    
    return all_passed

def validate_configuration_structure():
    """Validate configuration file structure"""
    
    print("\n🔧 Validating Configuration Structure")
    
    try:
        import glue_config
        
        # Check required configuration sections
        required_configs = [
            'REDSHIFT_CONFIG',
            'GLUE_JOB_CONFIG', 
            'DATA_QUALITY_CONFIG',
            'SPARK_CONFIG'
        ]
        
        all_present = True
        for config_name in required_configs:
            if hasattr(glue_config, config_name):
                print(f"   ✅ {config_name}: Present")
            else:
                print(f"   ❌ {config_name}: Missing")
                all_present = False
        
        # Check Redshift config keys
        redshift_keys = ['host', 'port', 'database', 'user', 'password', 'schema']
        redshift_config = glue_config.REDSHIFT_CONFIG
        
        for key in redshift_keys:
            if key in redshift_config:
                print(f"   ✅ REDSHIFT_CONFIG.{key}: Present")
            else:
                print(f"   ❌ REDSHIFT_CONFIG.{key}: Missing")
                all_present = False
        
        return all_present
        
    except ImportError as e:
        print(f"   ❌ Failed to import glue_config: {str(e)}")
        return False

def validate_file_structure():
    """Validate that all required files are present"""
    
    print("\n📁 Validating File Structure")
    
    import os
    
    required_files = [
        'glue_config.py',
        'data_quality_glue.py',
        'glue_job_script.py',
        'deploy_glue_job.py',
        'test_glue_local.py',
        'requirements.txt',
        'README.md'
    ]
    
    all_present = True
    for filename in required_files:
        if os.path.exists(filename):
            print(f"   ✅ {filename}: Present")
        else:
            print(f"   ❌ {filename}: Missing")
            all_present = False
    
    return all_present

def validate_import_structure():
    """Validate that Python imports work correctly"""
    
    print("\n📦 Validating Import Structure")
    
    try:
        # Test configuration import
        import glue_config
        print("   ✅ glue_config: Import successful")
        
        # Test that the main module can be imported (syntax check)
        import ast
        
        with open('data_quality_glue.py', 'r') as f:
            content = f.read()
        
        # Parse the file to check for syntax errors
        ast.parse(content)
        print("   ✅ data_quality_glue.py: Syntax valid")
        
        with open('glue_job_script.py', 'r') as f:
            content = f.read()
        
        ast.parse(content)
        print("   ✅ glue_job_script.py: Syntax valid")
        
        return True
        
    except SyntaxError as e:
        print(f"   ❌ Syntax error: {str(e)}")
        return False
    except ImportError as e:
        print(f"   ❌ Import error: {str(e)}")
        return False
    except Exception as e:
        print(f"   ❌ Unexpected error: {str(e)}")
        return False

def main():
    """Run all validation tests"""
    
    print("🚀 Starting AWS Glue Data Quality Validation")
    print("=" * 50)
    
    tests = [
        ("File Structure", validate_file_structure),
        ("Configuration Structure", validate_configuration_structure),
        ("Import Structure", validate_import_structure),
        ("OOTB Query Logic", validate_ootb_query_logic)
    ]
    
    results = []
    
    for test_name, test_func in tests:
        print(f"\n🧪 Running {test_name} validation...")
        try:
            result = test_func()
            results.append((test_name, result))
        except Exception as e:
            print(f"   ❌ Test failed with exception: {str(e)}")
            results.append((test_name, False))
    
    # Summary
    print("\n" + "=" * 50)
    print("📊 VALIDATION SUMMARY")
    print("=" * 50)
    
    all_passed = True
    for test_name, result in results:
        status = "✅ PASS" if result else "❌ FAIL"
        print(f"{test_name:.<30} {status}")
        if not result:
            all_passed = False
    
    print("\n" + "=" * 50)
    if all_passed:
        print("🎉 ALL VALIDATIONS PASSED!")
        print("   The AWS Glue job is ready for deployment.")
    else:
        print("❌ SOME VALIDATIONS FAILED!")
        print("   Please fix the issues before deploying.")
    
    return all_passed

if __name__ == "__main__":
    main()