"""
AWS Glue Data Quality Check Script
Compatible with AWS Glue 5.0 (Spark 3.4, Python 3.10)

This script performs data quality checks using PySpark on AWS Glue,
equivalent to the Redshift-based data quality script.
"""

import sys
import time
from datetime import datetime
from typing import Dict, List, Tuple, Optional, Any

from awsglue.transforms import *
from awsglue.utils import getResolvedOptions
from awsglue.context import GlueContext
from awsglue.job import Job
from awsglue.dynamicframe import DynamicFrame

from pyspark.context import SparkContext
from pyspark.sql import SparkSession, DataFrame
from pyspark.sql.functions import *
from pyspark.sql.types import *
import pyspark.sql.functions as F

import glue_config


class DataQualityGlue:
    """Data Quality Check Engine for AWS Glue"""
    
    def __init__(self, glue_context: GlueContext, job_name: str):
        self.glue_context = glue_context
        self.spark = glue_context.spark_session
        self.job_name = job_name
        self.logger = glue_context.get_logger()
        
        # Configuration
        self.redshift_config = glue_config.REDSHIFT_CONFIG
        self.target_schema = glue_config.DATA_QUALITY_CONFIG['target_schema']
        
        # Initialize Redshift connection options
        self.redshift_options = {
            "url": f"jdbc:redshift://{self.redshift_config['host']}:{self.redshift_config['port']}/{self.redshift_config['database']}",
            "user": self.redshift_config['user'],
            "password": self.redshift_config['password'],
            "driver": "com.amazon.redshift.jdbc42.Driver",
            "aws_iam_role": "arn:aws:iam::your-account:role/your-redshift-role"  # Update with your IAM role
        }
        
        self.logger.info(f"Initialized DataQualityGlue for job: {job_name}")
    
    def read_from_redshift(self, query: str) -> DataFrame:
        """Read data from Redshift using JDBC"""
        try:
            df = self.spark.read \
                .format("jdbc") \
                .options(**self.redshift_options) \
                .option("query", query) \
                .load()
            return df
        except Exception as e:
            self.logger.error(f"Error reading from Redshift: {str(e)}")
            raise
    
    def write_to_redshift(self, df: DataFrame, table_name: str, mode: str = "append"):
        """Write DataFrame to Redshift"""
        try:
            df.write \
                .format("jdbc") \
                .options(**self.redshift_options) \
                .option("dbtable", f"{self.target_schema}.{table_name}") \
                .mode(mode) \
                .save()
        except Exception as e:
            self.logger.error(f"Error writing to Redshift table {table_name}: {str(e)}")
            raise
    
    def get_next_run_id(self) -> int:
        """Get the next run ID for this execution"""
        try:
            query = f"SELECT COALESCE(MAX(run_id), 0) + 1 as next_id FROM {self.target_schema}.data_compare_log"
            result_df = self.read_from_redshift(query)
            next_id = result_df.collect()[0]['next_id']
            self.logger.info(f"Next run ID: {next_id}")
            return next_id
        except Exception as e:
            self.logger.error(f"Error getting next run ID: {str(e)}")
            return 1
    
    def get_check_configurations(self, process_id: int) -> DataFrame:
        """Get active check configurations for the given process ID"""
        query = f"""
        SELECT process_id, check_id, active, check_type, chunking_rule, 
               key_cols, src_qry, tgt_qry
        FROM {self.target_schema}.data_compare_check 
        WHERE active = true AND process_id = {process_id}
        ORDER BY check_id
        """
        return self.read_from_redshift(query)
    
    def build_ootb_query(self, check_type: str, key_cols: str, tgt_qry: str) -> Tuple[str, str]:
        """Build OOTB (Out of the Box) query based on check type"""
        
        if check_type == 'OOTB_DUPCHECK':
            # Duplicate check query
            count_query = f"SELECT COUNT(*) as count FROM (SELECT {key_cols}, COUNT(*) FROM {tgt_qry} GROUP BY {key_cols} HAVING COUNT(*) > 1) t"
            detail_query = f"SELECT {key_cols}, COUNT(*) as dup_count FROM {tgt_qry} GROUP BY {key_cols} HAVING COUNT(*) > 1"
            
        elif check_type == 'OOTB_NOTNULL':
            # Parse table.column format
            parts = tgt_qry.split('.')
            if len(parts) >= 3:
                table_name = ".".join(parts[:-1])
                column_name = parts[-1]
            else:
                table_name = parts[0] if len(parts) == 2 else tgt_qry
                column_name = parts[1] if len(parts) == 2 else key_cols
            
            count_query = f"SELECT COUNT(*) as count FROM {table_name} WHERE {column_name} IS NULL"
            detail_query = f"SELECT '{column_name}' as column_name, 'NULL' as failing_value FROM {table_name} WHERE {column_name} IS NULL LIMIT 1000"
            
        elif check_type == 'OOTB_MAXVAL':
            # Parse table.column format and threshold
            space_idx = tgt_qry.find(' ')
            table_col = tgt_qry[:space_idx]
            threshold = tgt_qry[space_idx:].strip()
            
            parts = table_col.split('.')
            if len(parts) >= 2:
                table_name = ".".join(parts[:-1])
                column_name = parts[-1]
            else:
                table_name = parts[0]
                column_name = key_cols
            
            count_query = f"SELECT COUNT(*) as count FROM {table_name} WHERE {column_name} > {threshold}"
            detail_query = f"SELECT {column_name} as failing_value FROM {table_name} WHERE {column_name} > {threshold} LIMIT 1000"
            
        elif check_type == 'OOTB_NOTIN':
            # Parse table.column format and allowed values
            space_idx = tgt_qry.find(' ')
            table_col = tgt_qry[:space_idx]
            allowed_values = tgt_qry[space_idx:].strip()
            
            parts = table_col.split('.')
            if len(parts) >= 2:
                table_name = ".".join(parts[:-1])
                column_name = parts[-1]
            else:
                table_name = parts[0]
                column_name = key_cols
            
            count_query = f"SELECT COUNT(*) as count FROM {table_name} WHERE {column_name} NOT IN ({allowed_values})"
            detail_query = f"SELECT {column_name} as failing_value FROM {table_name} WHERE {column_name} NOT IN ({allowed_values}) LIMIT 1000"
            
        elif check_type == 'OOTB_FKEY_NOTFOUND':
            # Parse foreign key check format: table1.col1 table2.col2
            parts = tgt_qry.split(' ')
            table1_col = parts[0].split('.')
            table2_col = parts[1].split('.')
            
            table1_name = ".".join(table1_col[:-1])
            col1_name = table1_col[-1]
            table2_name = ".".join(table2_col[:-1])
            col2_name = table2_col[-1]
            
            count_query = f"""
            SELECT COUNT(*) as count FROM {table1_name} 
            WHERE {col1_name} NOT IN (SELECT {col2_name} FROM {table2_name})
            """
            detail_query = f"""
            SELECT {col1_name} as failing_value FROM {table1_name} 
            WHERE {col1_name} NOT IN (SELECT {col2_name} FROM {table2_name})
            LIMIT 1000
            """
        else:
            raise ValueError(f"Unsupported OOTB check type: {check_type}")
        
        return count_query, detail_query
    
    def execute_check(self, check_config: Dict) -> Tuple[int, List[Dict], float]:
        """Execute a single data quality check"""
        start_time = time.time()
        
        check_id = check_config['check_id']
        check_type = check_config['check_type']
        key_cols = check_config['key_cols']
        src_qry = check_config['src_qry']
        tgt_qry = check_config['tgt_qry']
        
        self.logger.info(f"Processing Check ID {check_id} - Type: {check_type}")
        
        try:
            if check_type.startswith('OOTB_'):
                # Handle OOTB checks
                count_query, detail_query = self.build_ootb_query(check_type, key_cols, tgt_qry)
                
                # Get count of issues
                count_df = self.read_from_redshift(count_query)
                issue_count = count_df.collect()[0]['count']
                
                # Get detailed results if there are issues
                detail_results = []
                if issue_count > 0:
                    detail_df = self.read_from_redshift(detail_query)
                    detail_results = [row.asDict() for row in detail_df.collect()]
                
            elif check_type == 'COMPARE':
                # Handle comparison checks between source and target
                if src_qry and tgt_qry:
                    src_df = self.read_from_redshift(src_qry)
                    tgt_df = self.read_from_redshift(tgt_qry)
                    
                    # Perform comparison logic here
                    # This is a simplified version - you may need to enhance based on your comparison logic
                    src_count = src_df.count()
                    tgt_count = tgt_df.count()
                    issue_count = abs(src_count - tgt_count)
                    detail_results = [{'src_count': src_count, 'tgt_count': tgt_count}] if issue_count > 0 else []
                else:
                    issue_count = 0
                    detail_results = []
            else:
                # Handle custom queries
                if tgt_qry:
                    result_df = self.read_from_redshift(tgt_qry)
                    issue_count = result_df.count()
                    detail_results = [row.asDict() for row in result_df.collect()] if issue_count > 0 else []
                else:
                    issue_count = 0
                    detail_results = []
            
            duration = time.time() - start_time
            self.logger.info(f"Check {check_id} completed: {issue_count} issues found in {duration:.2f}s")
            
            return issue_count, detail_results, duration
            
        except Exception as e:
            duration = time.time() - start_time
            self.logger.error(f"Check {check_id} failed: {str(e)}")
            return -1, [], duration
    
    def store_log_result(self, process_id: int, run_id: int, check_id: int, 
                        check_type: str, issue_count: int, duration: float, 
                        error_reason: str = ""):
        """Store check result in log table"""
        
        # Determine status
        if issue_count == -1:
            status = f"ERROR-{check_type}"
        elif issue_count > 0:
            status = f"FAILED-{check_type}"
        else:
            status = "OK"
        
        # Create log record
        log_data = [(
            process_id, run_id, check_id, status, issue_count, 
            duration, datetime.now().strftime('%Y-%m-%d %H:%M:%S'), error_reason
        )]
        
        log_schema = StructType([
            StructField("process_id", IntegerType(), True),
            StructField("run_id", IntegerType(), True),
            StructField("check_id", IntegerType(), True),
            StructField("run_status", StringType(), True),
            StructField("numdiff", IntegerType(), True),
            StructField("run_duration", DoubleType(), True),
            StructField("run_date", StringType(), True),
            StructField("err_reason", StringType(), True)
        ])
        
        log_df = self.spark.createDataFrame(log_data, log_schema)
        self.write_to_redshift(log_df, "data_compare_log")
    
    def store_detail_results(self, process_id: int, run_id: int, check_id: int,
                           check_type: str, detail_results: List[Dict]):
        """Store detailed check results in diff table"""
        
        if not detail_results:
            return
        
        diff_records = []
        
        if check_type == 'OOTB_DUPCHECK':
            # Store duplicate details
            for result in detail_results:
                # Assuming result has the duplicate value and count
                if 'dup_count' in result:
                    key_col = [k for k in result.keys() if k != 'dup_count'][0]
                    duplicate_value = str(result[key_col])
                    count = result['dup_count']
                    
                    diff_records.append((
                        process_id, run_id, check_id, 'duplicate_check',
                        duplicate_value, str(count), 'DUPLICATE'
                    ))
        
        elif check_type in ['OOTB_NOTNULL', 'OOTB_MAXVAL', 'OOTB_NOTIN']:
            # Store failing values
            for result in detail_results:
                if 'failing_value' in result:
                    failing_value = str(result['failing_value'])
                    diff_records.append((
                        process_id, run_id, check_id, check_type.lower(),
                        failing_value, failing_value, 'FAILED'
                    ))
        
        elif check_type == 'OOTB_FKEY_NOTFOUND':
            # Store foreign key violations
            for result in detail_results:
                if 'failing_value' in result:
                    failing_value = str(result['failing_value'])
                    diff_records.append((
                        process_id, run_id, check_id, 'fkey_violation',
                        failing_value, failing_value, 'NOT_FOUND'
                    ))
        
        if diff_records:
            diff_schema = StructType([
                StructField("process_id", IntegerType(), True),
                StructField("run_id", IntegerType(), True),
                StructField("check_id", IntegerType(), True),
                StructField("colname", StringType(), True),
                StructField("pkeyval", StringType(), True),
                StructField("srcval", StringType(), True),
                StructField("tgtval", StringType(), True)
            ])
            
            diff_df = self.spark.createDataFrame(diff_records, diff_schema)
            self.write_to_redshift(diff_df, "data_compare_diff")
    
    def run_data_quality_checks(self, process_id: int) -> Tuple[int, float]:
        """Run all data quality checks for the given process ID"""
        
        start_time = time.time()
        run_id = self.get_next_run_id()
        
        self.logger.info(f"Starting data quality checks for Process ID: {process_id}, Run ID: {run_id}")
        
        # Get check configurations
        check_configs_df = self.get_check_configurations(process_id)
        check_configs = [row.asDict() for row in check_configs_df.collect()]
        
        if not check_configs:
            self.logger.warning(f"No active checks found for process ID: {process_id}")
            return 0, 0.0
        
        total_checks = len(check_configs)
        self.logger.info(f"Found {total_checks} active checks to execute")
        
        # Execute each check
        for check_config in check_configs:
            check_id = check_config['check_id']
            check_type = check_config['check_type']
            
            try:
                # Execute the check
                issue_count, detail_results, duration = self.execute_check(check_config)
                
                # Store log result
                self.store_log_result(
                    process_id, run_id, check_id, check_type, 
                    issue_count, duration
                )
                
                # Store detailed results if any issues found
                if issue_count > 0 and detail_results:
                    self.store_detail_results(
                        process_id, run_id, check_id, check_type, detail_results
                    )
                
            except Exception as e:
                error_msg = str(e)
                self.logger.error(f"Failed to execute check {check_id}: {error_msg}")
                
                # Store error result
                self.store_log_result(
                    process_id, run_id, check_id, check_type, 
                    -1, 0.0, error_msg
                )
        
        total_duration = time.time() - start_time
        self.logger.info(f"Completed {total_checks} checks in {total_duration:.2f} seconds")
        
        return total_checks, total_duration
    
    def generate_summary_report(self, run_id: int):
        """Generate summary report for the run"""
        
        # Get summary statistics
        summary_query = f"""
        SELECT run_status, COUNT(*) as check_count, SUM(numdiff) as total_differences 
        FROM {self.target_schema}.data_compare_log 
        WHERE run_id = {run_id} 
        GROUP BY run_status
        """
        
        summary_df = self.read_from_redshift(summary_query)
        summary_results = [row.asDict() for row in summary_df.collect()]
        
        self.logger.info("=== DATA QUALITY CHECK SUMMARY ===")
        self.logger.info(f"Run ID: {run_id}")
        
        for result in summary_results:
            status = result['run_status']
            count = result['check_count']
            differences = result['total_differences'] or 0
            self.logger.info(f"{status}: {count} checks, {differences} total issues")
        
        # Get failed checks details
        failed_query = f"""
        SELECT check_id, run_status, numdiff, err_reason 
        FROM {self.target_schema}.data_compare_log 
        WHERE run_id = {run_id} AND run_status != 'OK'
        """
        
        failed_df = self.read_from_redshift(failed_query)
        failed_results = [row.asDict() for row in failed_df.collect()]
        
        if failed_results:
            self.logger.info("\n=== FAILED CHECKS ===")
            for result in failed_results:
                check_id = result['check_id']
                status = result['run_status']
                issues = result['numdiff']
                error = result['err_reason'] or 'N/A'
                self.logger.info(f"Check {check_id}: {status} - {issues} issues - {error}")


def main():
    """Main function for AWS Glue job"""
    
    # Get job arguments
    args = getResolvedOptions(sys.argv, [
        'JOB_NAME',
        'process_id'  # Required parameter
    ])
    
    # Optional parameters with defaults
    process_id = int(args.get('process_id', glue_config.DATA_QUALITY_CONFIG['process_id']))
    
    # Initialize Glue context and job
    sc = SparkContext()
    glue_context = GlueContext(sc)
    job = Job(glue_context)
    job.init(args['JOB_NAME'], args)
    
    # Apply Spark configurations
    for key, value in glue_config.SPARK_CONFIG.items():
        sc.setLocalProperty(key, value)
    
    try:
        # Initialize data quality engine
        dq_engine = DataQualityGlue(glue_context, args['JOB_NAME'])
        
        # Run data quality checks
        total_checks, total_duration = dq_engine.run_data_quality_checks(process_id)
        
        # Generate summary report
        run_id = dq_engine.get_next_run_id() - 1  # Get the run ID we just used
        dq_engine.generate_summary_report(run_id)
        
        dq_engine.logger.info(f"Job completed successfully: {total_checks} checks in {total_duration:.2f}s")
        
    except Exception as e:
        glue_context.get_logger().error(f"Job failed: {str(e)}")
        raise
    
    finally:
        job.commit()


if __name__ == "__main__":
    main()