"""
AWS Glue Job Deployment Script
This script helps deploy the data quality job to AWS Glue
"""

import boto3
import json
from typing import Dict, Any

def create_glue_job(
    job_name: str,
    script_location: str,
    role_arn: str,
    glue_version: str = "5.0",
    worker_type: str = "G.1X",
    number_of_workers: int = 2,
    max_retries: int = 1,
    timeout: int = 2880,  # 48 hours in minutes
    additional_python_modules: str = "",
    extra_jars: str = "",
    temp_dir: str = "",
    job_parameters: Dict[str, Any] = None
) -> Dict[str, Any]:
    """
    Create or update AWS Glue job
    
    Args:
        job_name: Name of the Glue job
        script_location: S3 path to the job script
        role_arn: IAM role ARN for the job
        glue_version: Glue version (default: "5.0")
        worker_type: Worker type (G.1X, G.2X, etc.)
        number_of_workers: Number of workers
        max_retries: Maximum retries on failure
        timeout: Job timeout in minutes
        additional_python_modules: Additional Python modules to install
        extra_jars: Additional JAR files
        temp_dir: S3 temp directory
        job_parameters: Default job parameters
    
    Returns:
        Response from Glue service
    """
    
    glue_client = boto3.client('glue')
    
    # Default job parameters
    default_parameters = {
        '--job-language': 'python',
        '--job-bookmark-option': 'job-bookmark-disable',
        '--enable-metrics': 'true',
        '--enable-spark-ui': 'true',
        '--enable-continuous-cloudwatch-log': 'true',
        '--process_id': '11'  # Default process ID
    }
    
    # Add temp directory if provided
    if temp_dir:
        default_parameters['--TempDir'] = temp_dir
    
    # Add additional Python modules if provided
    if additional_python_modules:
        default_parameters['--additional-python-modules'] = additional_python_modules
    
    # Add extra JARs if provided (for Redshift JDBC driver)
    if extra_jars:
        default_parameters['--extra-jars'] = extra_jars
    
    # Merge with provided job parameters
    if job_parameters:
        default_parameters.update(job_parameters)
    
    # Job configuration
    job_config = {
        'Name': job_name,
        'Role': role_arn,
        'Command': {
            'Name': 'glueetl',
            'ScriptLocation': script_location,
            'PythonVersion': '3'
        },
        'DefaultArguments': default_parameters,
        'MaxRetries': max_retries,
        'Timeout': timeout,
        'GlueVersion': glue_version,
        'WorkerType': worker_type,
        'NumberOfWorkers': number_of_workers,
        'Description': 'Data Quality Check Job - PySpark version for AWS Glue 5.0'
    }
    
    try:
        # Try to get existing job
        response = glue_client.get_job(JobName=job_name)
        print(f"Job {job_name} exists. Updating...")
        
        # Update existing job
        response = glue_client.update_job(
            JobName=job_name,
            JobUpdate=job_config
        )
        print(f"✅ Job {job_name} updated successfully")
        
    except glue_client.exceptions.EntityNotFoundException:
        print(f"Job {job_name} does not exist. Creating...")
        
        # Create new job
        response = glue_client.create_job(**job_config)
        print(f"✅ Job {job_name} created successfully")
    
    return response

def upload_scripts_to_s3(bucket_name: str, prefix: str = "glue-scripts/data-quality/"):
    """
    Upload job scripts to S3
    
    Args:
        bucket_name: S3 bucket name
        prefix: S3 prefix for scripts
    
    Returns:
        Dictionary with S3 locations
    """
    
    s3_client = boto3.client('s3')
    
    scripts = [
        'glue_job_script.py',
        'data_quality_glue.py',
        'glue_config.py'
    ]
    
    s3_locations = {}
    
    for script in scripts:
        s3_key = f"{prefix}{script}"
        
        try:
            # Upload script to S3
            s3_client.upload_file(script, bucket_name, s3_key)
            s3_location = f"s3://{bucket_name}/{s3_key}"
            s3_locations[script] = s3_location
            print(f"✅ Uploaded {script} to {s3_location}")
            
        except Exception as e:
            print(f"❌ Failed to upload {script}: {str(e)}")
            raise
    
    return s3_locations

def create_iam_role_policy():
    """
    Generate IAM role policy document for Glue job
    
    Returns:
        Policy document as JSON string
    """
    
    policy = {
        "Version": "2012-10-17",
        "Statement": [
            {
                "Effect": "Allow",
                "Action": [
                    "glue:*",
                    "s3:GetBucketLocation",
                    "s3:ListBucket",
                    "s3:ListAllMyBuckets",
                    "s3:GetBucketAcl",
                    "s3:GetObject",
                    "s3:PutObject",
                    "s3:DeleteObject"
                ],
                "Resource": [
                    "*"
                ]
            },
            {
                "Effect": "Allow",
                "Action": [
                    "logs:CreateLogGroup",
                    "logs:CreateLogStream",
                    "logs:PutLogEvents"
                ],
                "Resource": "arn:aws:logs:*:*:*"
            },
            {
                "Effect": "Allow",
                "Action": [
                    "redshift:DescribeClusters",
                    "redshift:GetClusterCredentials"
                ],
                "Resource": "*"
            },
            {
                "Effect": "Allow",
                "Action": [
                    "secretsmanager:GetSecretValue"
                ],
                "Resource": "*"
            }
        ]
    }
    
    return json.dumps(policy, indent=2)

def main():
    """
    Main deployment function
    Example usage - update these values for your environment
    """
    
    # Configuration - UPDATE THESE VALUES
    JOB_NAME = "data-quality-checks-pyspark"
    S3_BUCKET = "your-glue-scripts-bucket"
    S3_PREFIX = "glue-scripts/data-quality/"
    IAM_ROLE_ARN = "arn:aws:iam::your-account:role/your-glue-role"
    TEMP_DIR = "s3://your-glue-temp-bucket/temp/"
    
    # Redshift JDBC driver (download from AWS)
    REDSHIFT_JDBC_JAR = "s3://your-bucket/jars/redshift-jdbc42-2.1.0.12.jar"
    
    print("🚀 Starting Glue job deployment...")
    
    try:
        # 1. Upload scripts to S3
        print("\n📤 Uploading scripts to S3...")
        s3_locations = upload_scripts_to_s3(S3_BUCKET, S3_PREFIX)
        
        # 2. Create/update Glue job
        print("\n🔧 Creating/updating Glue job...")
        
        job_parameters = {
            '--process_id': '11',  # Default process ID
            '--log_level': 'INFO'
        }
        
        response = create_glue_job(
            job_name=JOB_NAME,
            script_location=s3_locations['glue_job_script.py'],
            role_arn=IAM_ROLE_ARN,
            glue_version="5.0",
            worker_type="G.1X",
            number_of_workers=2,
            temp_dir=TEMP_DIR,
            extra_jars=REDSHIFT_JDBC_JAR,
            job_parameters=job_parameters
        )
        
        print(f"\n✅ Deployment completed successfully!")
        print(f"   Job Name: {JOB_NAME}")
        print(f"   Script Location: {s3_locations['glue_job_script.py']}")
        print(f"   IAM Role: {IAM_ROLE_ARN}")
        
        print(f"\n📋 To run the job:")
        print(f"   aws glue start-job-run --job-name {JOB_NAME}")
        print(f"   # Or with custom process ID:")
        print(f"   aws glue start-job-run --job-name {JOB_NAME} --arguments='--process_id=11'")
        
        print(f"\n📋 IAM Role Policy (if needed):")
        print(create_iam_role_policy())
        
    except Exception as e:
        print(f"❌ Deployment failed: {str(e)}")
        raise

if __name__ == "__main__":
    main()