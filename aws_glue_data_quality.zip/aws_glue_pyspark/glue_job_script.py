"""
AWS Glue Job Script for Data Quality Checks
This is the main entry point for the Glue job
"""

import sys
from awsglue.transforms import *
from awsglue.utils import getResolvedOptions
from awsglue.context import GlueContext
from awsglue.job import Job
from pyspark.context import SparkContext

# Import our data quality module
from data_quality_glue import DataQualityGlue
import glue_config
from datetime import datetime

def main():
    """Main entry point for AWS Glue job"""
    
    # Parse job arguments
    required_args = ['JOB_NAME']
    optional_args = ['process_id', 'log_level', 'temp_dir']
    
    # Get all available arguments
    all_args = required_args + optional_args
    args = getResolvedOptions(sys.argv, all_args)
    
    # Set defaults for optional parameters
    process_id = int(args.get('process_id', glue_config.DATA_QUALITY_CONFIG['process_id']))
    log_level = args.get('log_level', glue_config.GLUE_JOB_CONFIG['log_level'])
    
    # Initialize Spark and Glue contexts
    sc = SparkContext()
    glue_context = GlueContext(sc)
    spark = glue_context.spark_session
    job = Job(glue_context)
    
    # Initialize the job
    job.init(args['JOB_NAME'], args)
    
    # Set log level
    sc.setLogLevel(log_level)
    
    # Apply Spark configurations
    for key, value in glue_config.SPARK_CONFIG.items():
        spark.conf.set(key, value)
    
    logger = glue_context.get_logger()
    logger.info(f"Starting Data Quality job: {args['JOB_NAME']}")
    logger.info(f"Process ID: {process_id}")
    logger.info(f"Log Level: {log_level}")
    
    try:
        # Initialize the data quality engine
        dq_engine = DataQualityGlue(glue_context, args['JOB_NAME'])
        
        # Run the data quality checks
        logger.info("Executing data quality checks...")
        total_checks, total_duration = dq_engine.run_data_quality_checks(process_id)
        
        # Generate and log summary
        if total_checks > 0:
            run_id = dq_engine.get_next_run_id() - 1  # Get the run ID we just used
            dq_engine.generate_summary_report(run_id)
        
        logger.info(f"✅ Job completed successfully!")
        logger.info(f"   - Executed {total_checks} checks")
        logger.info(f"   - Total duration: {total_duration:.2f} seconds")
        
        # Job metrics for CloudWatch
        glue_context.write_dynamic_frame.from_options(
            frame=glue_context.create_dynamic_frame.from_rdd(
                sc.parallelize([{
                    'job_name': args['JOB_NAME'],
                    'process_id': process_id,
                    'total_checks': total_checks,
                    'total_duration': total_duration,
                    'status': 'SUCCESS',
                    'timestamp': str(datetime.now())
                }]),
                schema=None
            ),
            connection_type="s3",
            connection_options={
                "path": f"{glue_config.GLUE_JOB_CONFIG['output_dir']}/job_metrics/",
                "partitionKeys": ["job_name"]
            },
            format="json"
        )
        
    except Exception as e:
        error_msg = str(e)
        logger.error(f"❌ Job failed: {error_msg}")
        
        # Write error metrics
        try:
            glue_context.write_dynamic_frame.from_options(
                frame=glue_context.create_dynamic_frame.from_rdd(
                    sc.parallelize([{
                        'job_name': args['JOB_NAME'],
                        'process_id': process_id,
                        'status': 'FAILED',
                        'error_message': error_msg,
                        'timestamp': str(datetime.now())
                    }]),
                    schema=None
                ),
                connection_type="s3",
                connection_options={
                    "path": f"{glue_config.GLUE_JOB_CONFIG['output_dir']}/job_errors/",
                    "partitionKeys": ["job_name"]
                },
                format="json"
            )
        except:
            pass  # Don't fail the job if we can't write error metrics
        
        raise
    
    finally:
        # Commit the job
        job.commit()

if __name__ == "__main__":
    main()