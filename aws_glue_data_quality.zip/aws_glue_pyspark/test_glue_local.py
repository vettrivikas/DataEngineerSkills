"""
Local testing script for Glue data quality job
This script simulates the Glue environment for local testing
"""

import sys
import os
from unittest.mock import Mock, MagicMock
from pyspark.sql import SparkSession
from pyspark.sql.types import *
import pyspark.sql.functions as F

# Mock AWS Glue modules for local testing
class MockGlueContext:
    def __init__(self, spark_session):
        self.spark_session = spark_session
        self._logger = MockLogger()
    
    def get_logger(self):
        return self._logger

class MockLogger:
    def info(self, msg):
        print(f"INFO: {msg}")
    
    def error(self, msg):
        print(f"ERROR: {msg}")
    
    def warning(self, msg):
        print(f"WARNING: {msg}")

class MockJob:
    def __init__(self, glue_context):
        self.glue_context = glue_context
    
    def init(self, job_name, args):
        print(f"Initialized job: {job_name}")
    
    def commit(self):
        print("Job committed")

# Mock the AWS Glue modules
sys.modules['awsglue'] = Mock()
sys.modules['awsglue.transforms'] = Mock()
sys.modules['awsglue.utils'] = Mock()
sys.modules['awsglue.context'] = Mock()
sys.modules['awsglue.job'] = Mock()
sys.modules['awsglue.dynamicframe'] = Mock()

# Mock getResolvedOptions
def mock_get_resolved_options(argv, options):
    return {
        'JOB_NAME': 'test-data-quality-job',
        'process_id': '11'
    }

sys.modules['awsglue.utils'].getResolvedOptions = mock_get_resolved_options

# Now import our modules
import glue_config
from data_quality_glue import DataQualityGlue

class LocalDataQualityTester:
    """Local testing version of DataQualityGlue"""
    
    def __init__(self):
        # Initialize Spark session
        self.spark = SparkSession.builder \
            .appName("DataQualityLocalTest") \
            .config("spark.sql.adaptive.enabled", "true") \
            .getOrCreate()
        
        # Mock Glue context
        self.glue_context = MockGlueContext(self.spark)
        self.logger = self.glue_context.get_logger()
        
        # Create test data
        self.create_test_data()
    
    def create_test_data(self):
        """Create test data for local testing"""
        
        # Create test employee data with duplicates
        employee_data = [
            (1, "John", "Doe", "M", "john.doe@example.com", "555-1234", "1990-01-01", "Software Engineer"),
            (2, "Jane", "Smith", "F", "jane.smith@example.com", "555-5678", "1985-05-15", "Data Analyst"),
            (3, "Gwendolyn", "Sheppard", "F", "gwendolyn1@example.com", "555-9012", "1992-03-20", "Industrial buyer"),
            (4, "Bob", "Johnson", "M", "bob.johnson@example.com", "555-3456", "1988-12-10", None),  # NULL job_title
            (5, "Gwendolyn", "Sheppard", "F", "gwendolyn2@example.com", "555-7890", "1992-03-20", "Industrial buyer"),  # Duplicate
            (6, "Gwendolyn", "Williams", "F", "gwendolyn3@example.com", "555-2468", "1990-07-08", "Manager"),  # Duplicate first name
            (7, "Alice", "Brown", "F", "alice.brown@example.com", "555-1357", "1995-09-25", "Designer")
        ]
        
        employee_schema = StructType([
            StructField("id", IntegerType(), True),
            StructField("first_name", StringType(), True),
            StructField("last_name", StringType(), True),
            StructField("gender", StringType(), True),
            StructField("email", StringType(), True),
            StructField("phone", StringType(), True),
            StructField("dob", StringType(), True),
            StructField("job_title", StringType(), True)
        ])
        
        self.employee_df = self.spark.createDataFrame(employee_data, employee_schema)
        self.employee_df.createOrReplaceTempView("employee")
        
        # Create test check configurations
        check_config_data = [
            (11, 1002, True, "OOTB_NOTNULL", None, None, None, "employee.job_title"),
            (11, 1003, True, "OOTB_DUPCHECK", None, "first_name", None, "employee")
        ]
        
        check_config_schema = StructType([
            StructField("process_id", IntegerType(), True),
            StructField("check_id", IntegerType(), True),
            StructField("active", BooleanType(), True),
            StructField("check_type", StringType(), True),
            StructField("chunking_rule", StringType(), True),
            StructField("key_cols", StringType(), True),
            StructField("src_qry", StringType(), True),
            StructField("tgt_qry", StringType(), True)
        ])
        
        self.check_config_df = self.spark.createDataFrame(check_config_data, check_config_schema)
        self.check_config_df.createOrReplaceTempView("data_compare_check")
        
        self.logger.info("Test data created successfully")
    
    def mock_read_from_redshift(self, query: str):
        """Mock Redshift read operation using local Spark SQL"""
        try:
            # Replace schema references with local table names
            local_query = query.replace("dataquality.data_compare_check", "data_compare_check")
            local_query = local_query.replace("dataqualitypoc.dataquality.employee", "employee")
            local_query = local_query.replace("dataquality.employee", "employee")
            
            self.logger.info(f"Executing query: {local_query}")
            result_df = self.spark.sql(local_query)
            return result_df
        except Exception as e:
            self.logger.error(f"Query failed: {str(e)}")
            raise
    
    def test_duplicate_check(self):
        """Test duplicate check functionality"""
        
        self.logger.info("=== Testing Duplicate Check ===")
        
        # Test the duplicate query
        dup_query = """
        SELECT first_name, COUNT(*) as dup_count 
        FROM employee 
        GROUP BY first_name 
        HAVING COUNT(*) > 1
        """
        
        dup_df = self.mock_read_from_redshift(dup_query)
        dup_results = [row.asDict() for row in dup_df.collect()]
        
        self.logger.info(f"Found {len(dup_results)} duplicate groups:")
        for result in dup_results:
            self.logger.info(f"  {result['first_name']}: {result['dup_count']} occurrences")
        
        return dup_results
    
    def test_null_check(self):
        """Test null check functionality"""
        
        self.logger.info("=== Testing Null Check ===")
        
        # Test the null query
        null_query = "SELECT COUNT(*) as count FROM employee WHERE job_title IS NULL"
        
        null_df = self.mock_read_from_redshift(null_query)
        null_count = null_df.collect()[0]['count']
        
        self.logger.info(f"Found {null_count} null job_title values")
        
        if null_count > 0:
            # Get details
            detail_query = "SELECT id, first_name, last_name FROM employee WHERE job_title IS NULL"
            detail_df = self.mock_read_from_redshift(detail_query)
            detail_results = [row.asDict() for row in detail_df.collect()]
            
            self.logger.info("Null value details:")
            for result in detail_results:
                self.logger.info(f"  ID {result['id']}: {result['first_name']} {result['last_name']}")
        
        return null_count
    
    def test_check_configurations(self):
        """Test check configuration retrieval"""
        
        self.logger.info("=== Testing Check Configurations ===")
        
        config_query = """
        SELECT process_id, check_id, active, check_type, key_cols, tgt_qry
        FROM data_compare_check 
        WHERE active = true AND process_id = 11
        ORDER BY check_id
        """
        
        config_df = self.mock_read_from_redshift(config_query)
        configs = [row.asDict() for row in config_df.collect()]
        
        self.logger.info(f"Found {len(configs)} active check configurations:")
        for config in configs:
            self.logger.info(f"  Check {config['check_id']}: {config['check_type']} on {config['tgt_qry']}")
        
        return configs
    
    def run_full_test(self):
        """Run complete test suite"""
        
        self.logger.info("🧪 Starting Local Data Quality Tests")
        
        try:
            # Test 1: Check configurations
            configs = self.test_check_configurations()
            
            # Test 2: Duplicate check
            duplicates = self.test_duplicate_check()
            
            # Test 3: Null check
            null_count = self.test_null_check()
            
            # Summary
            self.logger.info("\n=== TEST SUMMARY ===")
            self.logger.info(f"✅ Found {len(configs)} check configurations")
            self.logger.info(f"✅ Found {len(duplicates)} duplicate groups")
            self.logger.info(f"✅ Found {null_count} null values")
            
            # Verify expected results
            expected_duplicates = 1  # Gwendolyn appears 3 times
            expected_nulls = 1       # Bob Johnson has null job_title
            
            if len(duplicates) == expected_duplicates and null_count == expected_nulls:
                self.logger.info("🎉 All tests passed!")
                return True
            else:
                self.logger.error(f"❌ Test results don't match expectations")
                return False
                
        except Exception as e:
            self.logger.error(f"❌ Tests failed: {str(e)}")
            return False
        
        finally:
            self.spark.stop()

def main():
    """Run local tests"""
    
    print("🚀 Starting Local Data Quality Tests")
    
    tester = LocalDataQualityTester()
    success = tester.run_full_test()
    
    if success:
        print("\n✅ Local tests completed successfully!")
        print("   The Glue job should work correctly when deployed.")
    else:
        print("\n❌ Local tests failed!")
        print("   Please check the implementation before deploying.")
    
    return success

if __name__ == "__main__":
    main()