import boto3
import json
import ast
from airflow import DAG
from airflow.operators.python import PythonOperator
from airflow.utils.dates import days_ago
from airflow.exceptions import AirflowException


def trigger_lambda(lambda_client, lambda_function_name, key, bucket, dest_path, errfolderpath, decrypt_secret_key, decrypt_assume_role):
    payload = {
        'key': key,
        'bucket': bucket,
        'dest_path': dest_path,
        'errfolderpath': errfolderpath,
        'pubKeyStoreName': decrypt_secret_key,
        'assumerolearn': decrypt_assume_role
    }

    print(f"Invoking Lambda: {lambda_function_name} with payload: {payload}")

    response = lambda_client.invoke(
        FunctionName=lambda_function_name,
        InvocationType='RequestResponse',
        Payload=json.dumps(payload)
    )

    response_payload = response['Payload'].read().decode('utf-8')
    print(f"Lambda Response: {response_payload}")

    try:
        parsed = ast.literal_eval(response_payload)
    except Exception as e:
        raise AirflowException(f"Failed to parse Lambda response: {e}")

    if int(parsed.get("statusCode", 500)) != 200:
        print(parsed.get("body", "No body returned"))
        raise AirflowException(f"Lambda {lambda_function_name} failed decrypting {key}")
    else:
        print(f"Lambda {lambda_function_name} succeeded for {key}")


def s3_copy_and_decrypt(**kwargs):
    s3 = boto3.client('s3')
    lambda_client = boto3.client('lambda')

    source_bucket = kwargs['dag_run'].conf.get('source_bucket')
    target_bucket = kwargs['dag_run'].conf.get('target_bucket')
    src_raw = kwargs['dag_run'].conf.get('source_keys')
    dst_raw = kwargs['dag_run'].conf.get('dest_keys')
    lambda_function_name = kwargs['dag_run'].conf.get('lambda_function_name')
    decrypt_secret_key = kwargs['dag_run'].conf.get('decrypt_secret_key')
    decrypt_assume_role = kwargs['dag_run'].conf.get('decrypt_assume_role')
    dest_path = kwargs['dag_run'].conf.get('staging_path')
    errfolderpath = kwargs['dag_run'].conf.get('error_path')

    source_keys = [src_raw] if isinstance(src_raw, str) else src_raw
    dest_keys = [dst_raw] if isinstance(dst_raw, str) else dst_raw

    if not (source_keys and dest_keys) or len(source_keys) != len(dest_keys):
        raise ValueError("source_keys and dest_keys must be non-empty and of equal length")

    for src, dst in zip(source_keys, dest_keys):
        src = src.strip()
        dst = dst.rstrip('/') + '/'

        folder_prefix = src if src.endswith('/') else src + '/'
        result = s3.list_objects_v2(Bucket=source_bucket, Prefix=folder_prefix, MaxKeys=1)
        is_folder = 'Contents' in result and result['Contents']

        if is_folder:
            paginator = s3.get_paginator('list_objects_v2')
            for page in paginator.paginate(Bucket=source_bucket, Prefix=folder_prefix):
                for obj in page.get('Contents', []):
                    skey = obj['Key']
                    if skey.endswith('/'):
                        continue
                    dkey = skey.replace(folder_prefix, dst, 1)
                    s3.copy_object(
                        Bucket=target_bucket,
                        CopySource={'Bucket': source_bucket, 'Key': skey},
                        Key=dkey
                    )
                    print(f"[folder] Copied {skey} → {dkey}")
                    if dkey.endswith('.pgp'):
                        trigger_lambda(lambda_client, lambda_function_name, dkey, target_bucket, dest_path, errfolderpath, decrypt_secret_key, decrypt_assume_role)
        else:
            file_name = src.split('/')[-1]
            dest_key = f"{dst}{file_name}"
            s3.copy_object(
                Bucket=target_bucket,
                CopySource={'Bucket': source_bucket, 'Key': src},
                Key=dest_key
            )
            print(f"[file] Copied {src} → {dest_key}")
            if dest_key.endswith('.pgp'):
                trigger_lambda(lambda_client, lambda_function_name, dest_key, target_bucket, dest_path, errfolderpath, decrypt_secret_key, decrypt_assume_role)


# Airflow DAG definition
with DAG(
    dag_id='s3_crossbucket_copy_with_lambda_decrypt',
    start_date=days_ago(1),
    schedule_interval=None,
    catchup=False,
    tags=['s3', 'lambda', 'decrypt']
) as dag:

    copy_and_decrypt = PythonOperator(
        task_id='copy_and_decrypt_pgp_files',
        python_callable=s3_copy_and_decrypt,
        provide_context=True
    )
